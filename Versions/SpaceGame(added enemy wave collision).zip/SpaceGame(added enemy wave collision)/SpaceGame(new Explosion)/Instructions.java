import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Instructions here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Instructions extends Buttons
{
    public Instructions(){
        GreenfootImage Inst = new GreenfootImage(230,60);
        Font adjFont = new Font(true, false, 39);
        Inst.setFont(adjFont);
        Inst.setColor(Color.BLACK);
        Inst.drawString("Instructions",0,50);
        setImage(Inst);
    }
    public void act()
    {
        checkMouse();
        checkIfClicked(new InstructionWorld());
    }
}
