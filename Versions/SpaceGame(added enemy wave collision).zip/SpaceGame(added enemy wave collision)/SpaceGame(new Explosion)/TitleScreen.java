import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TitleScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TitleScreen extends World
{
    //add sound here (bg music)
    /**
     * Constructor for objects of class TitleScreen.
     * 
     */
    public TitleScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 900, 1);
        prepare();
    }
    
    private void prepare(){
        GreenfootImage logo = new GreenfootImage("game-logo.png");
        Picture logoPic = new Picture(logo);
        addObject(logoPic,getWidth()/2,250);
        Play play = new Play();
        addObject(play,454,546);
        Instructions instructions = new Instructions();
        addObject(instructions,454,614);
        Exit exit = new Exit();
        addObject(exit,458,693);

        play.setLocation(444,557);
        instructions.setLocation(451,623);
        exit.setLocation(452,705);
        play.setLocation(452,544);
        instructions.setLocation(456,619);
        instructions.setLocation(454,624);
        exit.setLocation(452,705);
        exit.setLocation(459,706);
    }
    
    public void started(){
    //    soundtrack.play();
    }
    
    public void stopped(){
    //    soundtrack.stop();
    }
}
