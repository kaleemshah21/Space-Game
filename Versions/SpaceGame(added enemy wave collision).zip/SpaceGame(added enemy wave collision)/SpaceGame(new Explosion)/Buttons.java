import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Buttons here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Buttons extends Actor
{
    boolean mouseOver = false;
    int maxTrans = 255;
    public void checkMouse(){
        if(Greenfoot.mouseMoved(null)){
            mouseOver = Greenfoot.mouseMoved(this); //sets to true if over this object
            
        }
        
        if(mouseOver == true){
            transparency(maxTrans/2);
        }
        else{
            transparency(maxTrans);
        }
    }
    
    public void transparency(int amount){
        GreenfootImage tempImage = getImage();
        tempImage.setTransparency(amount);
        setImage(tempImage);
    }
    
    public void checkIfClicked(World world){
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.setWorld(world);
        }
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
