import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * button to take the user to the instructions screen.
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */
public class Instructions extends Buttons
{
    /*creates the text,colour and style of the button*/
    public Instructions(){
        GreenfootImage Inst = new GreenfootImage(230,60);
        Font adjFont = new Font(true, false, 39);
        Inst.setFont(adjFont);
        Inst.setColor(Color.BLACK);
        Inst.drawString("Instructions",0,50);
        setImage(Inst);
    }
    /*uses methods in parent class, checks if hovered and 
       checks if clicked, if so, instruction world is set.*/
    public void act()
    {
        checkMouse();
        checkIfClicked(new InstructionWorld());
    }
}
