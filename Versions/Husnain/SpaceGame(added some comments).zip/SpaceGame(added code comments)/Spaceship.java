import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.ArrayList;
/**
 * Write a description of class Spaceship here.
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */
public class Spaceship extends Actor
{
    boolean hittingBullet=false;    
    int speed = 3;
    int cooldown = 20;
    int timer = cooldown;
    int health = 100;
    MyWorld myWorld;
    Lose loseScreen;
    int numOfSpeedBoost = 0;
    int speedBoostDuration = 300; // 300 frames for 5 seconds
    int speedBoostTimer = 0;
    HealthBar healthbar;
    int bulspeed = 10;
    int score = 0;
    //constructor, gets MyWorld instance and passes through healthbar object
    public Spaceship(MyWorld world,HealthBar healthbar) {
        myWorld = world;
        this.healthbar = healthbar;
        getImage().scale(100,100);
    }

    /**
     * Act - do whatever the Spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    public void act()
    {
        //if player dead, return (prevents a few errors that were occuring.
        if (health <=0){
            return;
        }
        
        //calls methods
        moveToMouse();
        movement();
        shoot();
        isHit();
        isDead();
        isTouchingBoost();
        decrementShootingTimer();
        decrementSpeedBoostTimer();

    }
    public void decrementSpeedBoostTimer(){
        //if boost timer is above 0, it decrements, if its 0 it sets speed back to original
        if (speedBoostTimer > 0) {
            speedBoostTimer--;
            if (speedBoostTimer == 0) {
                // Speed boost duration is over, revert to normal speed
                speed -= 3;
            }
        }
    }
    public void decrementShootingTimer(){
        //shooting timer which decrements each frame
        if (timer > 0) {
            timer--;
        }
        
    }
    //takes a parameter to decide which boost is being picked up and decided what to do with it
    public void updateBoost(String boost){
        if(boost.equals("speed") && numOfSpeedBoost < 2){
            numOfSpeedBoost +=1; 
            myWorld.showBoosts(numOfSpeedBoost);
        }
        if(boost.equals("health")){
            health = 100;
            healthbar.resetHealth();
        }
        if(boost.equals("bullet")){
            bulspeed +=2;
        }
        
    }
    //checks if player is touching a boost
    /*was an issue where it would still check if touching after the player
    was removed, so it checks if the spaceship is still in the world
    if not, it returns. The rest of the method, gets an array of all
    speedboost objects that are touching the player, if its not empty,it
    gets the first object*/
    public void isTouchingBoost(){
        if (getWorld() == null) { 
        return;
        }
        List<Speedboost> speedBoosts = getIntersectingObjects(Speedboost.class);
        List<Healthboost> healthBoosts = getIntersectingObjects(Healthboost.class);
        List<Bulletboost> bulletBoosts = getIntersectingObjects(Bulletboost.class);
        if (!speedBoosts.isEmpty()) {
            Speedboost boost = speedBoosts.get(0);
            Greenfoot.playSound("665182__el_boss__item-or-material-pickup-pop-2-of-3.wav");
            World world = boost.getWorld();//returns a reference to the world the boost is in
            
            world.removeObject(boost);  // Remove the boost from the world
            updateBoost("speed"); //updates the number of boosts in the players inventory
            
        }
        if (!healthBoosts.isEmpty()) {
            Healthboost Hboost = healthBoosts.get(0);
            Greenfoot.playSound("665182__el_boss__item-or-material-pickup-pop-2-of-3.wav");
            World world = Hboost.getWorld();//returns a reference to the world the boost is in
            
            world.removeObject(Hboost);  // Remove the boost from the world
            updateBoost("health"); //updates the number of boosts in the players inventory
            
        }
        if (!bulletBoosts.isEmpty()) {
            Bulletboost Bboost = bulletBoosts.get(0);
            Greenfoot.playSound("665182__el_boss__item-or-material-pickup-pop-2-of-3.wav");
            World world = Bboost.getWorld();//returns a reference to the world the boost is in
            
            world.removeObject(Bboost);  // Remove the boost from the world
            updateBoost("bullet"); //updates the number of boosts in the players inventory
            
        }
    }
    //moves the player to the mouse
    public void moveToMouse(){
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null){
            turnTowards(mouse.getX(), mouse.getY()); 
        }
    }
    //checks if key is down and moves if the correct keys are pressed
    public void movement(){
        if(Greenfoot.isKeyDown("d") || Greenfoot.isKeyDown("right")){
            setLocation(getX() + speed, getY());
        }
        
        if(Greenfoot.isKeyDown("a") || Greenfoot.isKeyDown("left")){
            setLocation(getX() - speed, getY());
        }
        if(Greenfoot.isKeyDown("w") || Greenfoot.isKeyDown("up")){
            setLocation(getX(), getY()- speed);
        }
        
        if(Greenfoot.isKeyDown("s") || Greenfoot.isKeyDown("down")){
            setLocation(getX(), getY()+ speed);
        }
        
        if(Greenfoot.isKeyDown("space") && numOfSpeedBoost>0){
            //GreenfootSound sound = new GreenfootSound();
            Greenfoot.playSound("607409__colorscrimsontears__upgrade.wav");
            speedBoostTimer = speedBoostDuration;
            speed+=3;
            numOfSpeedBoost-=1;
            myWorld.showBoosts(numOfSpeedBoost);
        }
        
    }
    //creates bullet objects which move towards the mouse coordinates if timer is 0, plays a sound.
    public void shoot(){
        if(Greenfoot.mousePressed(null)){
            if (timer <= 0) {
                Pbullet bullet = new Pbullet();
                getWorld().addObject(bullet, getX(), getY());
                bullet.setBulletSpeed(bulspeed);
                bullet.turnTowards(Greenfoot.getMouseInfo().getX(), Greenfoot.getMouseInfo().getY());
                timer = cooldown; 
                Greenfoot.playSound("shooting-sound-fx-159024.mp3");
            }
        }
    }
    //checks all intersecting bullets and removes health from player and calls method to update healthbar
    public void isHit(){
        List<Bullet> bullets = getIntersectingObjects(Bullet.class); //gets all bullets that touch the enemy
        for (Bullet bullet : bullets) {
            if (health> 0) { // Checks that the player is alive
                health -= 40;//reduces health
                getWorld().removeObject(bullet);//removes the bullet
                healthbar.loseHealth();//tells the healthbar that the health has been reduced
                    
                
            }
        }
        
    }
    //checks if the health is 0 and plays sound and shows game over screen.
    public void isDead(){
        if(health <=0){
            getWorld().addObject(new Lose(),450,450);
            if(myWorld != null){
                myWorld.gameOver("lose");
            }
            
        }
    }
    //method to check if the player is alive
    public boolean isAlive() {
        return health > 0;
}
}
