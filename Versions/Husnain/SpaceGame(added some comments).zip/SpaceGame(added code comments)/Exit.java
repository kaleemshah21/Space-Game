import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * button used to end the game
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */
public class Exit extends Buttons
{
    TitleScreen titlescreen;
    /*creates the text for the button, colour and size*/
    public Exit(TitleScreen titlescreen){
        this.titlescreen=titlescreen;
        GreenfootImage exit = new GreenfootImage(100,60);
        Font adjFont = new Font(true, false, 39);
        exit.setFont(adjFont);
        exit.setColor(Color.BLACK);
        exit.drawString("Exit",0,50);
        setImage(exit);
    }
    /*uses the methods in the parent class to see if clicked,
       and to see if hovered,this then stops the game.*/
    public void act()
    {
        checkMouse();
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.stop();
            titlescreen.stopped();
        }
    }
}
