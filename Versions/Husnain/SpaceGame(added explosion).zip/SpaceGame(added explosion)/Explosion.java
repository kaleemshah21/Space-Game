import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Explosion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion extends Actor
{
    /**
     * Act - do whatever the Explosion wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int framesRemaining;
    public Explosion(){
        getImage().scale(40,30);
        framesRemaining = 0;
    }
    public void act()
    {
        if(framesRemaining > 0){
            framesRemaining --;
            if (framesRemaining == 0){
                getWorld().removeObject(this);
            }
        }
    }
    public void markedRemoval(int frames) {
        framesRemaining = frames;
    }
}
