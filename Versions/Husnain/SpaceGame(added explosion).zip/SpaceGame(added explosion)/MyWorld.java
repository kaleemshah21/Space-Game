import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    int height = getHeight(); //gets the world height
    int width = getWidth(); //gets the world width
    int enemiesRemoved = 0;
    int waveNumber = 0;
    List<Integer> enemyNum = new ArrayList<>();
    int lives = 3;
    Spaceship spaceship;
    Random rand = new Random();
    HealthBar healthbar = new HealthBar();
    int maxWaves = 10;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 900x900 cells with a cell size of 1x1 pixels.
        super(900, 900, 1); 
        prepare();
        initialiseWaves();
        addObject(healthbar, 60,875 );
        

        
         //this method isnt complete, trying to figure out how to do waves for the enemies
    }
    //returns the healthbar 
    public HealthBar getHealthBar()
    {
       return healthbar; 
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    //calls methods and creates spaceship object
    private void prepare()
    {   //creates all the objects for enemies and the player(spaceship)
        spaceship = new Spaceship(this,healthbar);
        addObject(spaceship,425,624);
        showLives();
        showScore();
        
        
        
        
    }
    public void restartGame(){
        Greenfoot.setWorld(new MyWorld());
    }
    public void showRestart(){
        this.addObject(new Restartbutton(this),450,700);
    }
    //checks if the remaining lives/misses are 0 and if so removes the spaceship and stops the game
    public void checkIfLivesZero(){ //getting issues
        if(lives <= 0){
          List<Spaceship> spaceships = getObjects(Spaceship.class);
          if(!spaceships.isEmpty()){
              spaceship.health = 0;
              this.addObject(new Lose(),450,450);
             
              showRestart();
              gameOver();
              
              
          }
        }
    }
    public void gameOver(){
        stopEnemies();
        removeObject(spaceship);
    }
    //keeps track of enemies killed and starts next wave when quota is reached
    public void addEnemyKilled(){
        enemiesRemoved+=1;
        if (waveNumber < enemyNum.size() && enemiesRemoved >= enemyNum.get(waveNumber-1)) {
            waves();
        }
    }
    //updates the misses enemies when called upon
    public void updateLives(){
        if (lives != 0){
            lives -=1;
            showLives();
            checkIfLivesZero();
        }
    }
    public void stopEnemies() {
        List<Enemy> enemies = getObjects(Enemy.class);
        for (Enemy enemy : enemies) {
            enemy.stopMoving(); // You need to add a stopMoving() method in the Enemy class
        }
    }
    //shows the remaining misses on screen
    public void showLives(){
        String text = ("misses left: " + lives);
        this.showText(text,800,800);
    }
    //shows the number of speed boosts in inventory
    public void showBoosts(int numOfBoosts){
        String boostText = ("speed boost: x " + numOfBoosts);
        this.showText(boostText,80,840);
    }
    //shows the score accumulated during the game
    public void showScore(){
        String scoreText = ("Score: " + spaceship.score);
        this.showText(scoreText,800,850);
    }
    //creates and adds values to an array for 10 waves and calls waves() method
    public void initialiseWaves(){
        for(int x=0;x<=maxWaves;x++){
           enemyNum.add(x + 2); 
        }

        waves();
        
    }
    //creates enemy objects until value in array is met 
    public void waves(){ //not done just messing around with waves of enemies
        waveNumber++; 
        boolean contact = false;
        if(lives <=0){
            return;
        }
        if (waveNumber < enemyNum.size()+1) {
            if(waveNumber == maxWaves + 1){
                this.addObject(new Win(),450,450);
                showRestart();
                gameOver();
                return;
            }
            int num = enemyNum.get(waveNumber-1);
            for (int j = 0; j < num; j++) {
                Enemy enemy = new Enemy(this);
                addObject(enemy,rand.nextInt(100,(width-100)),rand.nextInt(30,80));
            }
            enemiesRemoved = 0; //resets the enemies removed for next wave
        }
    
    }
}
