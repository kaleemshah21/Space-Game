import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * an instructions screen to tell the user what keys do what
 * 
 * @author kaleem, husnain, jake
 * @version (14/12/2023)
 */
public class InstructionWorld extends World
{

    /**
     * Constructor for objects of class InstructionWorld.
     * Create a new world with 900x900 cells with a cell size of 1x1 pixels.
     * sets a few String variables to text of movement and game keybinds
     * shows the text on the screen
     */
    public InstructionWorld()
    {    
        super(900, 900, 1);
        // Creates a new menu button and displays it on screen
        Menu menu = new Menu();
        addObject(menu,461,730);
        // sets variables to text explaining the game controls
        String instructions = "Movement: left = a or ← \n right = d or → \n up = w or ↑ \n down = s or ↓ \n";
        String instructions2 = "Shoot: Mouse to aim, left click to shoot \n";
        String instructions3 = "Boosts: SpeedBoost = space \n";
        // shows the instructions String on screen
        showText(instructions,getWidth()/2,250);
        showText(instructions2,getWidth()/2,325);
        showText(instructions3,getWidth()/2,350);

    }
}
