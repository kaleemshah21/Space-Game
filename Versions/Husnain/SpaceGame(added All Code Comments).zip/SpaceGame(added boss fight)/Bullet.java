import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * bullet class to create bullet objects.
 * each bullet has its own speed which can be changed
 * it also removes the bullet when hitting the sides of
 * the game or when touching player bullets.
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */

public class Bullet extends Actor
{
    int speed = 10; //set a variable for the speed
    boolean isBossBullet = false;
    //method to update speed of bullet
    public void setBulletSpeed(int bulspeed){
        speed = bulspeed;
    }
    public void setBossBullet(){
        isBossBullet = true;
    }
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //calles method and moves the bullet
    public void act()
    {
        move(speed); //move method just moves the object
        removeBullet();
    }
    //if the bullet hits the walls it gets removed or is touching a player bullet
    public void removeBullet(){
        if(!isBossBullet){
            if (this.getY() == 0 || this.getX() == 0 || this.getX() == getWorld().getWidth() -1 || this.getY() == getWorld().getHeight()-1 || isTouching(Pbullet.class)){
                getWorld().removeObject(this);
            }
        }
        else{
            if (this.getY() == 0 || this.getX() == 0 || this.getX() == getWorld().getWidth() -1 || this.getY() == getWorld().getHeight()-1){
                getWorld().removeObject(this);
            }
        }
        
        
    }
}
