import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * a title screen for the game, shows a logo
 * and buttons
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */
public class TitleScreen extends World
{
    //sets the soundtrack variable to the correct path
    GreenfootSound soundtrack = new GreenfootSound("dreams.mp3");
    /**
     * Constructor for objects of class TitleScreen.
     * Create a new world with 900x900 cells with a cell size of 1x1 pixels.
     * calls the prepare method
     */
    public TitleScreen()
    {    
        super(900, 900, 1);
        prepare();
    }
    /*adds the logo to the screen,
       adds play, instructions, exit buttons to the screen,
       sets the location of each button*/
    private void prepare(){
        GreenfootImage logo = new GreenfootImage("game-logo.png");
        Picture logoPic = new Picture(logo);
        addObject(logoPic,getWidth()/2,250);
        Play play = new Play();
        addObject(play,454,546);
        Instructions instructions = new Instructions();
        addObject(instructions,454,614);
        Exit exit = new Exit(this);
        addObject(exit,458,693);

        play.setLocation(444,557);
        instructions.setLocation(451,623);
        exit.setLocation(452,705);
        play.setLocation(452,544);
        instructions.setLocation(456,619);
        instructions.setLocation(454,624);
        exit.setLocation(452,705);
        exit.setLocation(459,706);
    }
    //plays the soundtrack when the game is started
    public void started(){
        soundtrack.play();
        soundtrack.setVolume(15);
    }
    //stops the soundtrack when the game is ended
    public void stopped(){
        soundtrack.stop();
        soundtrack.setVolume(15);
    }
}
