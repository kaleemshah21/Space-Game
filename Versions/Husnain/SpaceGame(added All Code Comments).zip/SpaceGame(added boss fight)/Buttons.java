import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * button class, has a few default methods 
 * that can be used by all button classes
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */
public class Buttons extends Actor
{
    boolean mouseOver = false;
    int maxTrans = 255;
    /*checks if the mouse is hovering over the button,
       if so, the transparency method is called to change
       transparency*/
    public void checkMouse(){
        if(Greenfoot.mouseMoved(null)){
            mouseOver = Greenfoot.mouseMoved(this); //sets to true if over this object
            
        }
        
        if(mouseOver == true){
            transparency(maxTrans/2);
        }
        else{
            transparency(maxTrans);
        }
    }
    /*sets the button to a transparency that is 
       passed through when called*/
    public void transparency(int amount){
        GreenfootImage tempImage = getImage();
        tempImage.setTransparency(amount);
        setImage(tempImage);
    }
    /*checks if the button is clicked,
       if so it sets the world to the world that is
       passed through*/
    public void checkIfClicked(World world){
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.setWorld(world);
        }
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
