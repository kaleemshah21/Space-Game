import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Picture here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Picture extends Actor
{
    /**
     * Act - do whatever the Picture wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    // sets the image to the url that is passed through (used for the logo)
    public Picture(GreenfootImage myImage){
        setImage(myImage);
    }
    public void act()
    {
        // Add your action code here.
    }
}
