import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.lang.Math;
/**
 * Write a description of class HealthBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthBar extends Actor
{
    // declares variables
    int health = 3;
    int healthBarWidth = 78;
    int healthBarHeight = 15;
    int pixelsPerHealthPoint = (int)healthBarWidth/health;
    GreenfootImage healthBarImage;
    //GreenfootImage myImage = getImage();
    
    /**
     * Act - do whatever the HealthBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public HealthBar()
    {
        healthBarImage = new GreenfootImage(healthBarWidth + 2, healthBarHeight + 2);
        update();
    }
    public void act()
    {
        update();
        
        
    }
    //resets the health back to original value
    public void resetHealth(){
        health = 3;
    }
    //updates the healthbar image
    public void update()
    {
        
        //setImage(new GreenfootImage(healthBarWidth + 2, healthBarHeight + 2));
        
        setImage(healthBarImage);
        healthBarImage.clear();
        
        healthBarImage.setColor(greenfoot.Color.WHITE);
        healthBarImage.drawRect(0, 0, healthBarWidth + 1, healthBarHeight + 1);
        healthBarImage.setColor(greenfoot.Color.RED);
        healthBarImage.fillRect(1,1, health*pixelsPerHealthPoint, healthBarHeight);
        setImage(healthBarImage);
        
        
    }
    //decrements the health when called upon
    public void loseHealth()
    {
       health--;
    }
}
