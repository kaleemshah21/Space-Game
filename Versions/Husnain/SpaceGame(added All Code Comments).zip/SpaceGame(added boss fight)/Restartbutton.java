import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 * Write a description of class Restartbutton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Restartbutton extends Actor
{
    MyWorld world;
    /**
     * Act - do whatever the Restartbutton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    // scales the button and creates an instance of the world
    public Restartbutton(MyWorld world){
        getImage().scale(175,55);
        this.world = world;
    }
    // calls the methods restardWorld and hover
    public void act()
    {
        restartWorld();
        hover();
    }
    // add a hover effect when hovering over the button
    public void hover(){
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if(mouse!=null){
            boolean hover = false;
            List<Restartbutton> objects = getWorld().getObjectsAt(mouse.getX(), mouse.getY(), Restartbutton.class);
            for (Object object : objects)
            {
                if (object == this)
                {
                    setImage("play-again-h.png");
                    getImage().scale(175,55);
                    hover = true;
                }
            }
            if(!hover){
                    this.setImage("play-again.png");
                    getImage().scale(175,55);
                }
            
            /*if(Greenfoot.mouseMoved(this)){
                this.setImage("play-again-h.png");
                getImage().scale(175,55);
            }
            else{
                this.setImage("play-again.png");
                getImage().scale(175,55);
            }*/
            
        }
    }
    // restarts the game by calling a method in the world class
    public void restartWorld(){
        if(Greenfoot.mouseClicked(this)){
            world.restartGame();
        }
    }
}
