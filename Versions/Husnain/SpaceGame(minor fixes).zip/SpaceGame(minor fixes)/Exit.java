import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Exit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Exit extends Buttons
{
    TitleScreen titlescreen;
    public Exit(TitleScreen titlescreen){
        this.titlescreen=titlescreen;
        GreenfootImage exit = new GreenfootImage(100,60);
        Font adjFont = new Font(true, false, 39);
        exit.setFont(adjFont);
        exit.setColor(Color.BLACK);
        exit.drawString("Exit",0,50);
        setImage(exit);
    }
    public void act()
    {
        checkMouse();
        if(Greenfoot.mouseClicked(this)){
            Greenfoot.stop();
            titlescreen.stopped();
        }
    }
}
