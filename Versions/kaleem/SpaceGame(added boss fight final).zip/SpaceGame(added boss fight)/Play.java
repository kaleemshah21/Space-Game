import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * loads the game world when clicked.
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */
public class Play extends Buttons
{
    /*sets the text and colour for the button*/
    public Play(){
        GreenfootImage play = new GreenfootImage(100,60);
        Font adjFont = new Font(true, false, 50);
        play.setFont(adjFont);
        play.setColor(Color.BLACK);
        play.drawString("Play",0,50);
        setImage(play);
    }
    /*uses methods in parent class, checks if hovered and 
       checks if clicked, if so, MyWorld world is opened.*/
    public void act()
    {
        checkMouse();
        checkIfClicked(new MyWorld());
    }
}
