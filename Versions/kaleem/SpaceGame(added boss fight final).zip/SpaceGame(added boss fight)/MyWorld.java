import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 * Main Game world, prepares all objects of enemies and player, sets up all variables and methods
 * that need to be used by both itself and other classes
 * 
 * @author kaleem, husnain, jake
 * @version (14/12/2023)
 */
public class MyWorld extends World
{
    /*sets variables to default values
       or declares needed variables or arrays
       e.g. number of max waves or a default 
       collision value for the enemy waves.*/
       
    int height = getHeight(); //gets the world height
    int width = getWidth(); //gets the world width
    int enemiesRemoved = 0;
    int waveNumber = 0;
    List<Integer> enemyNum = new ArrayList<>();
    int lives = 3;
    Spaceship spaceship;
    Random rand = new Random();
    HealthBar healthbar = new HealthBar();
    int maxWaves = 5;
    boolean collision = false;
    
    /**
     * Constructor for objects of class MyWorld.
     * Create a new world with 900x900 cells with a cell size of 1x1 pixels.
     * calls the prepare and initialiseWaves methods
     * adds a player healthbar on screen
     */
    public MyWorld()
    {    
        super(900, 900, 1); 
        prepare();
        initialiseWaves();
        addObject(healthbar, 60,875 );
    }
    //returns the healthbar 
    public HealthBar getHealthBar()
    {
       return healthbar; 
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     * calls other methods likes showLives and showScore
     * creates a spaceship object and adds it to the world
     */
    //calls methods and creates spaceship object
    private void prepare()
    {   //creates all the objects for enemies and the player(spaceship)
        spaceship = new Spaceship(this,healthbar);
        addObject(spaceship,425,624);
        showLives();
        showScore();
    }
    /*restarts the game when called */
    public void restartGame(){
        Greenfoot.setWorld(new MyWorld());
    }
    /*checks if the remaining lives/misses are 0 and if so removes the spaceship and stops the game*/
    public void checkIfLivesZero(){ //getting issues
        if(lives <= 0){
          List<Spaceship> spaceships = getObjects(Spaceship.class);
          if(!spaceships.isEmpty()){
              spaceship.health = 0;
              gameOver("lose");
          }
        }
    }
    /*takes a String input, when called with "lose", displays lose screen
       when called with "win", displays the win screen
       then shows the menu and stops enemies
       then removes the spaceship*/
    public void gameOver(String outcome){
        if(outcome.equals("lose")){
            this.addObject(new Lose(),450,450);
            Greenfoot.playSound("videogame-death-sound-43894.mp3");
        }
        else if(outcome.equals("win")){
            this.addObject(new Win(),450,450);
        }
        showMenu();
        stopEnemies();
        removeSpaceship();
    }
    /*removes the spaceship*/
    public void removeSpaceship(){
        removeObject(spaceship);
    }
    /*creates a new restart button and menu button
       it then displays them on screen*/
    public void showMenu(){
        this.addObject(new Restartbutton(this),450,700);
        Menu menu = new Menu();
        addObject(menu,456,807);
    }
    //keeps track of enemies killed and starts next wave when quota is reached
    public void addEnemyKilled(){
        enemiesRemoved+=1;
        if (waveNumber < enemyNum.size() && enemiesRemoved >= enemyNum.get(waveNumber-1)) {
            waves();
        }
    }
    //updates the misses/lives when called upon
    public void updateLives(){
        if (lives != 0){
            lives -=1;
            showLives();
            checkIfLivesZero();
        }
    }
    public void setLivesZero(){
        lives = 0;
        showLives();
        checkIfLivesZero();
    }
    /*gets a list of all enemies and for each enemy
       stops them from moving
       it then calls the removeAllBullets method*/
    public void stopEnemies() {
        List<Enemy> enemies = getObjects(Enemy.class);
        for (Enemy enemy : enemies) {
            enemy.stopMoving();
        }
        removeAllBullets();
    }
    /*cycles through the array and removes all bullet objects*/
    public void removeAllBullets(){
        List<Pbullet> bullets = getObjects(Pbullet.class);
        for (Pbullet bullet : bullets){
            removeObject(bullet);
        }
    }
    //shows the remaining misses on screen
    public void showLives(){
        String text = ("misses left: " + lives);
        this.showText(text,800,800);
    }
    //shows the number of speed boosts in inventory
    public void showBoosts(int numOfBoosts){
        String boostText = ("speed boost: x " + numOfBoosts);
        this.showText(boostText,80,840);
    }
    //shows the score accumulated during the game
    public void showScore(){
        String scoreText = ("Score: " + spaceship.score);
        this.showText(scoreText,800,850);
    }
    //adds values to an array until maxWaves is reached and calls waves() method
    public void initialiseWaves(){
        for(int x=0;x<=maxWaves;x++){
           enemyNum.add(x + 2); 
        }
        waves();
    }
    /*takes the list of enemies at the location added and the enemy object that has just been added,
       it then checks if there is a collision, sets a boolean value and if there is a collision,
       it removes the enemy*/
    public void checkWaveCollision(List enemies,Enemy enemy){
        if(enemies.size() > 1){
            removeObject(enemy);
            collision = true;
        }
        else{
            collision = false;
        }
    }
    /*cycles through the array with the current wave,then adds an enemy (calls addenemy method),
       until collision is false, it then resets the enemies removed for next wave*/
    public void spawnWave(){
        int num = enemyNum.get(waveNumber-1);
        for (int j = 0; j < num; j++) {
            do{
                addEnemy();
            }while(collision);
        }
            enemiesRemoved = 0;
        
    }
    /*creates a new enemy object, adds it in a somewhat random location,
       gets all objects at the location the enemy was added at,
       calls the checkwavecollision method and passes through the enemy that
       has just been added as well as the list of all objects at the location*/
    public void addEnemy(){
        Enemy enemy = new Enemy(this);
        addObject(enemy,rand.nextInt(100,(width-100)),rand.nextInt(30,80));
        List<Enemy> enemies = getObjectsAt(enemy.getX(), enemy.getY(), Enemy.class);
        checkWaveCollision(enemies,enemy);
    }
    /*increments the wave number every time it is called
       if the number of misses/lives is 0, it returns.
       if there are still waves left in the array, it then
       checks if the wave number is the max waves (won), which
       will call the game over method,
       if not, it will spawn a new wave (calls spawnWave method)*/
    public void waves(){ //not done just messing around with waves of enemies
        waveNumber++; 
        if(lives <=0){
            return;
        }
        if (waveNumber < enemyNum.size()+1) {
            if(waveNumber == maxWaves + 1){
                //gameOver("win");
                spawnBoss();
                return;
            }
            spawnWave();
        }
    
    }
    public void spawnBoss(){
        Enemy bossEnemy = new Enemy(this);
        addObject(bossEnemy,450,30);
        bossEnemy.setBulletCooldown(20);
        bossEnemy.setBossImage();
        bossEnemy.setBoolBoss();
        bossEnemy.setHealth(2000);
        bossEnemy.setSpeed(1);
    }
}
