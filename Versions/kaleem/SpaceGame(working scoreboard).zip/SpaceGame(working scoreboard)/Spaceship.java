import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.ArrayList;
/**
 * Write a description of class Spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spaceship extends Actor
{
    boolean hittingBullet=false;    
    int speed = 3;
    int cooldown = 20;
    int timer = cooldown;
    int health = 100;
    MyWorld myWorld;
    Lose loseScreen;
    int numOfSpeedBoost = 0;
    int speedBoostDuration = 300; // 300 frames for 5 seconds
    int speedBoostTimer = 0;
    HealthBar healthbar;
    int bulspeed = 10;
    int score = 0;
    public Spaceship(MyWorld world) {
        myWorld = world;
    }
    public Spaceship(HealthBar healthbar){
        this.healthbar = healthbar; //the issue was that a new healthbar was being made, this just passes through the correct bar
    }
    /**
     * Act - do whatever the Spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Spaceship(){

    }
    public void act()
    {
        if (health <=0){
            return;
        }
        moveToMouse();
        movement();
        shoot();
        isHit();
        isDead();
        isTouchingBoost();
        if (timer > 0) {
            timer--; // Decrease the timer in each frame
        }
        if (speedBoostTimer > 0) {
            speedBoostTimer--;
            if (speedBoostTimer == 0) {
                // Speed boost duration is over, revert to normal speed
                speed -= 3;
            }
        }
    }
    public void updateBoost(String boost){
        if(boost.equals("speed") && numOfSpeedBoost < 2){
            numOfSpeedBoost +=1;  
        }
        if(boost.equals("health")){
            health = 100;
            healthbar.resetHealth();
        }
        if(boost.equals("bullet")){
            bulspeed +=2;
        }
        
    }
    public void isTouchingBoost(){
        /*was an issue where it would still check if touching after the player
           was removed, so it checks if the spaceship is still in the world
           if not, it returns. The rest of the method, gets an array of all
           speedboost objects that are touching the player, if its not empty,it
           gets the first object*/
        if (getWorld() == null) { 
        return;
        }
        List<Speedboost> speedBoosts = getIntersectingObjects(Speedboost.class);
        List<Healthboost> healthBoosts = getIntersectingObjects(Healthboost.class);
        List<Bulletboost> bulletBoosts = getIntersectingObjects(Bulletboost.class);
        if (!speedBoosts.isEmpty()) {
            Speedboost boost = speedBoosts.get(0);
            
            World world = boost.getWorld();//returns a reference to the world the boost is in
            
            world.removeObject(boost);  // Remove the boost from the world
            updateBoost("speed"); //updates the number of boosts in the players inventory
            
        }
        if (!healthBoosts.isEmpty()) {
            Healthboost Hboost = healthBoosts.get(0);
            
            World world = Hboost.getWorld();//returns a reference to the world the boost is in
            
            world.removeObject(Hboost);  // Remove the boost from the world
            updateBoost("health"); //updates the number of boosts in the players inventory
            
        }
        if (!bulletBoosts.isEmpty()) {
            Bulletboost Bboost = bulletBoosts.get(0);
            
            World world = Bboost.getWorld();//returns a reference to the world the boost is in
            
            world.removeObject(Bboost);  // Remove the boost from the world
            updateBoost("bullet"); //updates the number of boosts in the players inventory
            
        }
    }
    public void moveToMouse(){
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null){
            turnTowards(mouse.getX(), mouse.getY()); 
        }
    }
    public void movement(){
        if(Greenfoot.isKeyDown("d")){
            setLocation(getX() + speed, getY());
        }
        
        if(Greenfoot.isKeyDown("a")){
            setLocation(getX() - speed, getY());
        }
        if(Greenfoot.isKeyDown("w")){
            setLocation(getX(), getY()- speed);
        }
        
        if(Greenfoot.isKeyDown("s")){
            setLocation(getX(), getY()+ speed);
        }
        
        if(Greenfoot.isKeyDown("space") && numOfSpeedBoost>0){
            speedBoostTimer = speedBoostDuration;
            speed+=3;
            numOfSpeedBoost-=1;
        }
        
    }
    public void shoot(){
        if(Greenfoot.mousePressed(null)){
            if (timer <= 0) {
                Pbullet bullet = new Pbullet();
                getWorld().addObject(bullet, getX(), getY());
                bullet.setBulletSpeed(bulspeed);
                bullet.turnTowards(Greenfoot.getMouseInfo().getX(), Greenfoot.getMouseInfo().getY());
                timer = cooldown; 
            }
        }
    }
    public void isHit(){
        List<Bullet> bullets = getIntersectingObjects(Bullet.class); //gets all bullets that touch the enemy
        for (Bullet bullet : bullets) {
            if (health> 0) { // Checks that the player is alive
                health -= 40;//reduces health
                getWorld().removeObject(bullet);//removes the bullet
                healthbar.loseHealth();//tells the healthbar that the health has been reduced
                    
                
            }
        }
        
    }
    public void isDead(){
        if(health <=0){
            getWorld().addObject(new Lose(),450,450);
            getWorld().removeObject(this);
            Greenfoot.stop();
        }
    }
    public boolean isAlive() {
        return health > 0;
}
}
