import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends Buttons
{
    public Menu(){
        GreenfootImage menu = new GreenfootImage(100,60);
        Font adjFont = new Font(true, false, 40);
        menu.setFont(adjFont);
        menu.setColor(Color.WHITE);
        menu.drawString("Menu",0,50);
        setImage(menu);
    }
    
    public void act()
    {
        checkMouse();
        checkIfClicked(new TitleScreen());
    }
}
