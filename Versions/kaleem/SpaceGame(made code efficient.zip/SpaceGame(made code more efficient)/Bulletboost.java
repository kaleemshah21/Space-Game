import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bulletboost here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bulletboost extends Actor
{
    /**
     * Act - do whatever the Bulletboost wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //sets the image size
    public Bulletboost(){
        getImage().scale(40,30);
    }
    public void act()
    {
        // Add your action code here.
    }
}
