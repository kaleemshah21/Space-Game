import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Healthbar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Healthbar extends Actor
{
    

public class HealthBar extends Actor {
    private int health; // current health
    private int maxHealth; // maximum health

    public HealthBar(int initialHealth, int maxHealth) {
        this.health = initialHealth;
        this.maxHealth = maxHealth;
        updateImage();
    }

    public void updateImage() {
        GreenfootImage image = new GreenfootImage(maxHealth + 2, 20);
        image.setColor(greenfoot.Color.RED);
        image.fillRect(1, 1, maxHealth, 18);
        image.setColor(greenfoot.Color.GREEN);
        image.fillRect(1, 1, health, 18);
        setImage(image);
    }

    public void setHealth(int health) {
        this.health = health;
        updateImage();
    }
}

}
