import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Pbullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pbullet extends Actor
{
    int speed = 10;
    public void setBulletSpeed(int bulspeed){
        speed = bulspeed;
    }
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(speed);
        removeBullet();
    }
    public void increaseBulletSize(){
        
    }
    
    public void removeBullet(){
        if (this.getY() == 0 || this.getX() == 0 || this.getX() == getWorld().getWidth() -1 || this.getY() == getWorld().getHeight()-1){
            getWorld().removeObject(this);
        }
    }
}
