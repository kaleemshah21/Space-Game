import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.Random;
import java.lang.Math;
/**
 * Write a description of class Enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy extends Actor
{
    MyWorld myWorld; //declares the variable world as an instance of myWolrd class
    Spaceship player;
    Random rand = new Random();
    int speed = rand.nextInt(1,3);
    int health = 100;
    int shootCooldown = rand.nextInt(60,120);
    int currentCooldown = shootCooldown;
    boolean isMarkedForRemoval = false;
    Speedboost sBoost;
    Healthboost hBoost;
    Bulletboost bBoost;
    
    
    public Enemy(MyWorld world) {
        myWorld = world;
    }
    
    /**
     * Act - do whatever the Enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if (player == null) {
            // If player is not yet set, try to find the player object
            player = getWorld().getObjects(Spaceship.class).get(0);
        }

        if (player != null) {
            pointTowardsPlayer();
        }
        if (currentCooldown > 0) {
            currentCooldown--; // Decrease the timer in each frame
        }

        moveDownScreen();
        checkIfAtBottom();
        checkIfHit();
        checkIfHealthGone();
        shoot();
        removal();
        
    }   
    public void checkIfAtBottom(){
        if(this.getY() == getWorld().getHeight()-1){
            health = 0;
        if(player != null){
            myWorld.updateLives();
            
        }
        }
    }
    public void pointTowardsPlayer(){
        if (player != null && player.getWorld() != null) {
            turnTowards(player.getX(), player.getY()); 
        }
    }
    public void moveDownScreen(){
        setLocation(getX(), getY()+ speed);
    }
    public void removeBullets() {
        List<Pbullet> bullets = getIntersectingObjects(Pbullet.class);
        for (Pbullet bullet : bullets) {
            getWorld().removeObject(bullet);
        }
    }
    public void checkIfHit(){
        if(isTouching(Pbullet.class)){
            health -=100;
            removeBullets();
            player.score +=10;
            myWorld.showScore();
        }
    }
    public void checkIfHealthGone(){
        if (getWorld().getObjects(Enemy.class) != null){
            if(health <= 0){
                isMarkedForRemoval = true;
            }
        }    
    }
    public void removal(){
        if(isMarkedForRemoval){
            myWorld.addEnemyKilled(); // Increment the count if myWorld is not null
            int dropX = this.getX();
            int dropY = this.getY();
            var drop = Math.random();
            if(myWorld !=null){
                if(drop < 0.1){
                    sBoost = new Speedboost();
                    getWorld().addObject(sBoost, dropX, dropY);
                    
                }
                if(drop < 0.2 && drop >0.1){
                    hBoost = new Healthboost();
                    getWorld().addObject(hBoost,dropX,dropY);
                    
                }
                if(drop > 0.35 && drop < 0.45){
                    bBoost = new Bulletboost();
                    getWorld().addObject(bBoost,dropX,dropY);
                }
                getWorld().removeObject(this);
            }
            
        }
        
    }
    public void shoot(){
        if (currentCooldown == 0 && player != null && player.isAlive()) {
            Bullet bullet = new Bullet();
            bullet.setBulletSpeed(rand.nextInt(3,5));
            getWorld().addObject(bullet, getX(), getY());
            bullet.turnTowards(player.getX(), player.getY());
            currentCooldown = shootCooldown;
        }
    }
}
