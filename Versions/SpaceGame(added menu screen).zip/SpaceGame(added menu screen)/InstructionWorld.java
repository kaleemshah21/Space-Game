import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class InstructionWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InstructionWorld extends World
{

    /**
     * Constructor for objects of class InstructionWorld.
     * 
     */
    public InstructionWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 900, 1);
        Menu menu = new Menu();
        addObject(menu,461,730);
        String instructions = "Movement: left = a or ← \n right = d or → \n up = w or ↑ \n down = s or ↓ \n";
        String instructions2 = "Shoot: Mouse to aim, left click to shoot \n";
        String instructions3 = "Boosts: SpeedBoost = space \n";
        showText(instructions,getWidth()/2,250);
        showText(instructions2,getWidth()/2,325);
        showText(instructions3,getWidth()/2,350);

    }
}
