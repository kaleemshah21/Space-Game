import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.ArrayList;
/**
 * Write a description of class Spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spaceship extends Actor
{
    int speed = 3;
    int cooldown = 20;
    int timer = cooldown;
    int health = 100;
    MyWorld myWorld;
    Lose loseScreen;
    public Spaceship(MyWorld world) {
        myWorld = world;
    }
    /**
     * Act - do whatever the Spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Spaceship(){

    }
    public void act()
    {
        moveToMouse();
        movement();
        shoot();
        isHit();
        isDead();
        if (timer > 0) {
            timer--; // Decrease the timer in each frame
        }
    }
    public void moveToMouse(){
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null){
            turnTowards(mouse.getX(), mouse.getY()); 
        }
    }
    public void movement(){
        if(Greenfoot.isKeyDown("d")){
            setLocation(getX() + speed, getY());
        }
        
        if(Greenfoot.isKeyDown("a")){
            setLocation(getX() - speed, getY());
        }
        if(Greenfoot.isKeyDown("w")){
            setLocation(getX(), getY()- speed);
        }
        
        if(Greenfoot.isKeyDown("s")){
            setLocation(getX(), getY()+ speed);
        }
        
    }
    public void shoot(){
        if(Greenfoot.mousePressed(null)){
            if (timer <= 0) {
                Pbullet bullet = new Pbullet();
                getWorld().addObject(bullet, getX(), getY());
                bullet.turnTowards(Greenfoot.getMouseInfo().getX(), Greenfoot.getMouseInfo().getY());
                timer = cooldown; 
            }
        }
    }
    public void isHit(){
        List<Bullet> bullets = getIntersectingObjects(Bullet.class); //gets all bullets that touch the enemy
        for (Bullet bullet : bullets) {
            if (health> 0) { // Check the flag in Bullet class
                health -= 40;
                getWorld().removeObject(bullet);
            }
        }
        
    }
    public void isDead(){
        if(health <=0){
            getWorld().addObject(new Lose(),450,450);
            getWorld().removeObject(this);
            Greenfoot.stop();
        }
    }
}
