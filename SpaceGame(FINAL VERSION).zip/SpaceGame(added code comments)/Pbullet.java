import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * bullet class to create Pbullet objects.
 * each bullet has its own speed which can be changed
 * it also removes the bullet when hitting the sides of
 * the game or when touching enemies
 * 
 * @author (kaleem,husnain,jake) 
 * @version (14/12/2023)
 */
public class Pbullet extends Actor
{
    //value of speed
    int speed = 10;
    //method to change speed
    public void setBulletSpeed(int bulspeed){
        speed = bulspeed;
    }
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //calls method and moves the bullet object
    public void act()
    {
        move(speed);
        removeBullet();
    }
    public void increaseBulletSize(){
        
    }
    //removes bullet if touching walls.
    public void removeBullet(){
        if (this.getY() == 0 || this.getX() == 0 || this.getX() == getWorld().getWidth() -1 || this.getY() == getWorld().getHeight()-1){
            getWorld().removeObject(this);
        }
    }
}
