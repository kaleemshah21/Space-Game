import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * boost that gives the player 100% health back when interacted with
 * 
 * @author (Kaleem, Husnain, Jake) 
 * @version (14/12/2023)
 */
public class Healthboost extends Actor
{
    /**
     * Act - do whatever the Healthboost wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //sets image size on screen
    public Healthboost(){
        getImage().scale(39,35);
    }
    public void act()
    {
        // Add your action code here.
    }
}
