import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * takes the user back to the titlescreen
 * 
 * @author kaleem,husnain,jake 
 * @version (14/12/2023)
 */
public class Menu extends Buttons
{
    /*sets the text and colour for the button*/
    public Menu(){
        GreenfootImage menu = new GreenfootImage(100,60);
        Font adjFont = new Font(true, false, 40);
        menu.setFont(adjFont);
        menu.setColor(Color.WHITE);
        menu.drawString("Menu",0,50);
        setImage(menu);
    }
    /*uses methods in parent class, checks if hovered and 
       checks if clicked, if so, titlescreen world is opened.*/
    public void act()
    {
        checkMouse();
        checkIfClicked(new TitleScreen());
    }
}
