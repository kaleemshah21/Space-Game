import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * used to show images on screen, for example the main menu logo.
 * 
 * @author (Kaleem, Husnain, Jake) 
 * @version (14/12/2023)
 */
public class Picture extends Actor
{
    /**
     *sets the image to the image passed through
     */
    public Picture(GreenfootImage myImage){
        setImage(myImage);
    }
    public void act()
    {
        // Add your action code here.
    }
}
