import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Speedboost here.
 * 
 * @author (Kaleem, Husnain, Jake) 
 * @version (14/12/2023)
 */
public class Speedboost extends Actor
{
    /**
     * Act - do whatever the Speedboost wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //sets the image size on screen
    public Speedboost(){
        getImage().scale(40,30);
    }
    public void act()
    {
        // Add your action code here.
    }
}
