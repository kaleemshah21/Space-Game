import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Lose screen when the game is over
 * 
 * @author (Kaleem, Husnain, Jake) 
 * @version (14/12/2023)
 */
public class Lose extends Actor
{
    /**
     * Act - do whatever the Lose wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
